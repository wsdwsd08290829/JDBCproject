java -classpath .:mysql-connector-java-5.1.26-bin.jar Hw3 dbparams.txt q2 1660 35
