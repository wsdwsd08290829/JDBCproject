java -classpath .:mysql-connector-java-5.1.26-bin.jar Populate dbparams.txt players.csv teams.csv members.csv tournaments.csv matches.csv earnings.csv
