javac -classpath .:mysql-connector-java-5.1.26-bin.jar Hw3.java
