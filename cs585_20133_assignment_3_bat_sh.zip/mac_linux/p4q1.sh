java -classpath .:mysql-connector-java-5.1.26-bin.jar Hw3 dbparams.txt q1 1990 10
